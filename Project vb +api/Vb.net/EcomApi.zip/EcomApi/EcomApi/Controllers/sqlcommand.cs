﻿namespace EcomApi.Controllers
{
    internal class sqlcommand
    {
        public sqlcommand()
        {
        }
    }
}